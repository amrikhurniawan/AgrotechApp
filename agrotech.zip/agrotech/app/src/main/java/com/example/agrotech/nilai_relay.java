package com.example.agrotech;

public class nilai_relay {
    public int nilai;
    public nilai_relay(){

    }
    public nilai_relay(int nilai) {
        this.nilai = nilai;
    }
}
