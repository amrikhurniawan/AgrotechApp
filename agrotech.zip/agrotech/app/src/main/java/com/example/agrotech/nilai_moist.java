package com.example.agrotech;

public class nilai_moist {
    public int nilai;
    public nilai_moist(){

    }
    public nilai_moist(int nilai) {
        this.nilai = nilai;
    }
}
