package com.example.agrotech;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class hal_monitor extends AppCompatActivity {
    DatabaseReference dbref, reference;
    ImageView tombol_signout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hal_monitor);

        dbref = FirebaseDatabase.getInstance().getReference("moisture");
        reference = FirebaseDatabase.getInstance().getReference("relay");
        TextView kelembaban = findViewById(R.id.kelembapan_tanah);

        dbref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    nilai_moist nilaiMoist = dataSnapshot.getValue(nilai_moist.class);
                    int moist = nilaiMoist.nilai;
                    Log.d("mytag", "nilaimoist"+moist);
                    String moistt = Integer.toString(moist);
                    kelembaban.setText(moistt);
                }

            }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(hal_monitor.this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            });

        final TextView status = (TextView) findViewById(R.id.status_pompa);
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    nilai_relay sstatus = dataSnapshot.getValue(nilai_relay.class);
                    int statuss = sstatus.nilai;
                    Log.d("mytag", "nilaimoist"+statuss);
                    if(statuss == 1){
                        status.setText("Off");
                    }
                    else{
                        status.setText("On");
                    }
                }}
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(hal_monitor.this, "Something Wrong Happened!", Toast.LENGTH_SHORT).show();
            }
        });
        tombol_signout = findViewById(R.id.signout_tombol);
        tombol_signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(hal_monitor.this,hal_login.class));
            }
        });
    }
}