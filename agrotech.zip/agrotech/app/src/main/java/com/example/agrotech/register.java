package com.example.agrotech;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;

public class register extends AppCompatActivity implements View.OnClickListener {
    FirebaseAuth mAuth;
    EditText password1, email1;
    ImageView button_register;
  TextView login_buttton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        button_register = findViewById(R.id.tombol_register);
        button_register.setOnClickListener(this);
        password1 = findViewById(R.id.passwordd);
        email1 = findViewById(R.id.emaill);

       login_buttton = findViewById(R.id.tombol_login);
        login_buttton.setOnClickListener(view -> startActivity(new Intent(register.this,hal_login.class)));
    }
    @Override
    public void onClick (View view){
        switch (view.getId()) {
            case R.id.tombol_register:
                registeruser();
                break;
        }
    }
    private void registeruser() {
                    final String email2 = email1.getText().toString().trim();
                    String pass = password1.getText().toString().trim();
                    if (email2.isEmpty()) {
                        email1.setError("Email is required!");
                        email1.requestFocus();
                        return;
                    }
                    if (pass.isEmpty()) {
                        password1.setError("Password is required!");
                        password1.requestFocus();
                        return;
                    }
                    mAuth.createUserWithEmailAndPassword(email2, pass)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(register.this, "User has been registered successfully!", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(register.this, hal_login.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(register.this, "Failed!", Toast.LENGTH_LONG).show();
                                }
                            });
                }
         }
